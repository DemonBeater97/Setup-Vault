@echo off
title Setup Vault
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js fehlt. Bitte von https://nodejs.org installieren ^(LTS-Version^) und start.bat neu starten.
  pause
  exit /b
)
set PORT=4747
rem App-Fenster nach 2 Sekunden oeffnen (Edge als eigenes Fenster, sonst Standard-Browser)
start "" /min cmd /c "timeout /t 2 >nul & (start msedge --app=http://localhost:%PORT% || start http://localhost:%PORT%)"
node server.js
pause
