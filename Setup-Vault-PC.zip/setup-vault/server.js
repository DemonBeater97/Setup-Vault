// Setup Vault – lokaler Server
// Startet die App auf deinem PC und speichert alle Profile in data/vault.json.
// Dein Handy verbindet sich über dasselbe WLAN. Keine Pakete nötig, nur Node.js.

const http = require("http");
const fs = require("fs");
const path = require("path");
const os = require("os");

const PORT = Number(process.env.PORT) || 4747;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const DATA_FILE = path.join(DATA_DIR, "vault.json");

// ---------- Speicher ----------
let vault = { version: 0, profiles: {} };
function loadVault() {
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
    if (raw && typeof raw.profiles === "object") vault = { version: raw.version || 0, profiles: raw.profiles };
  } catch (e) { /* noch keine Datei – startet leer */ }
}
let saveTimer = null;
function saveVault() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = DATA_FILE + ".tmp";
    fs.writeFileSync(tmp, JSON.stringify(vault, null, 2));
    fs.renameSync(tmp, DATA_FILE); // erst komplett schreiben, dann ersetzen
  }, 200);
}
// Tägliche Sicherung (die letzten 7 bleiben)
function backup() {
  try {
    if (!fs.existsSync(DATA_FILE)) return;
    const dir = path.join(DATA_DIR, "backups");
    fs.mkdirSync(dir, { recursive: true });
    const day = new Date().toISOString().slice(0, 10);
    const file = path.join(dir, `vault-${day}.json`);
    if (!fs.existsSync(file)) fs.copyFileSync(DATA_FILE, file);
    fs.readdirSync(dir).filter(f => f.startsWith("vault-")).sort().slice(0, -7)
      .forEach(f => fs.unlinkSync(path.join(dir, f)));
  } catch (e) { console.warn("Sicherung fehlgeschlagen:", e.message); }
}

// ---------- Live-Updates an alle offenen Geräte ----------
const clients = new Set();
function broadcast() {
  const msg = `data: ${JSON.stringify({ version: vault.version })}\n\n`;
  clients.forEach(res => res.write(msg));
}

// ---------- Hilfen ----------
function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family === "IPv4" && !a.internal) out.push(a.address);
    }
  }
  // Heimnetz-Adressen zuerst
  return out.sort((a, b) => (/^192\.168\./.test(b) - /^192\.168\./.test(a)));
}
function sendJson(res, code, obj) {
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on("data", c => { size += c.length; if (size > 2_000_000) { reject(new Error("zu groß")); req.destroy(); } else chunks.push(c); });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".json": "application/json", ".webmanifest": "application/manifest+json", ".svg": "image/svg+xml", ".png": "image/png", ".css": "text/css" };
function cleanProfile(b) {
  return {
    name: String(b.name || "").slice(0, 120), author: String(b.author || "").slice(0, 80),
    game: String(b.game || "").slice(0, 80), plat: String(b.plat || "").slice(0, 40),
    created: Number(b.created) || Date.now(), updated: Number(b.updated) || Date.now(),
    s: (b.s && typeof b.s === "object") ? b.s : {}, checks: (b.checks && typeof b.checks === "object") ? b.checks : {}
  };
}

// ---------- Server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://x");
  const p = url.pathname;
  try {
    if (p === "/api/profiles" && req.method === "GET") {
      return sendJson(res, 200, { version: vault.version, profiles: vault.profiles });
    }
    const m = p.match(/^\/api\/profiles\/([A-Za-z0-9_-]{1,40})$/);
    if (m && req.method === "PUT") {
      const body = JSON.parse(await readBody(req));
      vault.profiles[m[1]] = cleanProfile(body);
      vault.version++; saveVault(); broadcast();
      return sendJson(res, 200, { ok: true, version: vault.version });
    }
    if (m && req.method === "DELETE") {
      delete vault.profiles[m[1]];
      vault.version++; saveVault(); broadcast();
      return sendJson(res, 200, { ok: true, version: vault.version });
    }
    if (p === "/api/events") {
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-store", Connection: "keep-alive" });
      res.write(`data: ${JSON.stringify({ version: vault.version })}\n\n`);
      clients.add(res);
      const ping = setInterval(() => res.write(": ping\n\n"), 25000);
      req.on("close", () => { clearInterval(ping); clients.delete(res); });
      return;
    }
    if (p === "/api/info") {
      return sendJson(res, 200, { port: PORT, addresses: lanAddresses() });
    }
    // Dateien aus public/
    const file = path.normalize(path.join(PUBLIC, p === "/" ? "index.html" : p));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" }); return res.end("Nicht gefunden"); }
      res.writeHead(200, { "Content-Type": TYPES[path.extname(file)] || "application/octet-stream", "Cache-Control": "no-cache" });
      res.end(data);
    });
  } catch (e) {
    sendJson(res, 400, { error: e.message });
  }
});

loadVault();
backup();
server.listen(PORT, "0.0.0.0", () => {
  const ips = lanAddresses();
  console.log("");
  console.log("  ███ SETUP VAULT läuft ███");
  console.log("");
  console.log(`  Am PC:      http://localhost:${PORT}`);
  ips.forEach(ip => console.log(`  Am Handy:   http://${ip}:${PORT}   (gleiches WLAN)`));
  console.log("");
  console.log("  Profile werden gespeichert in: " + DATA_FILE);
  console.log("  Dieses Fenster offen lassen. Beenden mit Strg+C.");
  console.log("");
});
server.on("error", e => {
  if (e.code === "EADDRINUSE") console.error(`Port ${PORT} ist schon belegt. Läuft Setup Vault schon? Sonst in start.bat einen anderen PORT eintragen.`);
  else console.error(e);
  process.exitCode = 1;
});
